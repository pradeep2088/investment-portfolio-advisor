import React, { useState } from 'react';
import { PieChart, DollarSign, TrendingUp, Briefcase, ArrowUpRight, ArrowDownRight, X, Calendar, BarChart3, Percent, Calculator } from 'lucide-react';

interface Asset {
  name: string;
  value: number;
  change: number;
  allocation: number;
  details?: {
    term: string;
    expectedReturn: number;
    risk: string;
    minimumInvestment: number;
  };
}

interface ModalProps {
  asset: Asset;
  onClose: () => void;
}

interface InvestmentRecommendation {
  assetName: string;
  amount: number;
  percentage: number;
}

function AssetDetailsModal({ asset, onClose }: ModalProps) {
  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50">
      <div className="bg-white rounded-2xl max-w-2xl w-full p-6 relative">
        <button
          onClick={onClose}
          className="absolute right-4 top-4 text-gray-400 hover:text-gray-600"
        >
          <X className="w-6 h-6" />
        </button>

        <div className="mb-6">
          <h2 className="text-2xl font-bold text-gray-900 mb-2">{asset.name} Details</h2>
          <div className="flex items-center gap-2 text-gray-600">
            <DollarSign className="w-5 h-5" />
            <span className="text-xl">${asset.value.toLocaleString()}</span>
            <span className={`flex items-center gap-1 ${
              asset.change >= 0 ? 'text-green-600' : 'text-red-600'
            }`}>
              {asset.change >= 0 ? (
                <ArrowUpRight className="w-4 h-4" />
              ) : (
                <ArrowDownRight className="w-4 h-4" />
              )}
              <span>{Math.abs(asset.change)}%</span>
            </span>
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <div className="bg-gray-50 rounded-xl p-4">
            <div className="flex items-center gap-2 mb-3">
              <Calendar className="w-5 h-5 text-indigo-600" />
              <h3 className="font-semibold text-gray-900">Investment Term</h3>
            </div>
            <p className="text-gray-600">{asset.details?.term}</p>
          </div>

          <div className="bg-gray-50 rounded-xl p-4">
            <div className="flex items-center gap-2 mb-3">
              <BarChart3 className="w-5 h-5 text-indigo-600" />
              <h3 className="font-semibold text-gray-900">Expected Return</h3>
            </div>
            <p className="text-gray-600">{asset.details?.expectedReturn}% annually</p>
          </div>

          <div className="bg-gray-50 rounded-xl p-4">
            <div className="flex items-center gap-2 mb-3">
              <TrendingUp className="w-5 h-5 text-indigo-600" />
              <h3 className="font-semibold text-gray-900">Risk Level</h3>
            </div>
            <p className="text-gray-600">{asset.details?.risk}</p>
          </div>

          <div className="bg-gray-50 rounded-xl p-4">
            <div className="flex items-center gap-2 mb-3">
              <Percent className="w-5 h-5 text-indigo-600" />
              <h3 className="font-semibold text-gray-900">Minimum Investment</h3>
            </div>
            <p className="text-gray-600">${asset.details?.minimumInvestment.toLocaleString()}</p>
          </div>
        </div>

        <div className="mt-6 p-4 bg-blue-50 rounded-xl border border-blue-100">
          <h3 className="font-semibold text-blue-800 mb-2">Investment Strategy</h3>
          <p className="text-blue-600">
            {asset.name === 'Stocks' && 'Focus on diversified equity investments across major markets for long-term growth.'}
            {asset.name === 'Bonds' && 'Provide stable income and reduce portfolio volatility through fixed-income securities.'}
            {asset.name === 'Real Estate' && 'Generate rental income and capital appreciation through property investments.'}
            {asset.name === 'Cash' && 'Maintain liquidity and provide a safety buffer for short-term needs.'}
          </p>
        </div>
      </div>
    </div>
  );
}

function App() {
  const [selectedAsset, setSelectedAsset] = useState<Asset | null>(null);
  const [investmentAmount, setInvestmentAmount] = useState<string>('');
  const [recommendations, setRecommendations] = useState<InvestmentRecommendation[]>([]);
  const [assets] = useState<Asset[]>([
    {
      name: 'Stocks',
      value: 45000,
      change: 2.3,
      allocation: 45,
      details: {
        term: 'Long-term (5+ years)',
        expectedReturn: 8.5,
        risk: 'Moderate to High',
        minimumInvestment: 1000,
      },
    },
    {
      name: 'Bonds',
      value: 30000,
      change: -0.5,
      allocation: 30,
      details: {
        term: 'Medium-term (2-5 years)',
        expectedReturn: 4.2,
        risk: 'Low to Moderate',
        minimumInvestment: 5000,
      },
    },
    {
      name: 'Real Estate',
      value: 15000,
      change: 1.2,
      allocation: 15,
      details: {
        term: 'Long-term (7+ years)',
        expectedReturn: 6.8,
        risk: 'Moderate',
        minimumInvestment: 10000,
      },
    },
    {
      name: 'Cash',
      value: 10000,
      change: 0.1,
      allocation: 10,
      details: {
        term: 'Short-term (0-1 year)',
        expectedReturn: 1.5,
        risk: 'Very Low',
        minimumInvestment: 0,
      },
    },
  ]);

  const totalValue = assets.reduce((sum, asset) => sum + asset.value, 0);

  const calculateRecommendations = (amount: number) => {
    const riskProfile = amount < 10000 ? 'conservative' : amount < 50000 ? 'moderate' : 'aggressive';
    
    let allocations: { [key: string]: number } = {
      conservative: { Stocks: 30, Bonds: 40, 'Real Estate': 20, Cash: 10 },
      moderate: { Stocks: 50, Bonds: 30, 'Real Estate': 15, Cash: 5 },
      aggressive: { Stocks: 70, Bonds: 20, 'Real Estate': 8, Cash: 2 }
    }[riskProfile];

    return Object.entries(allocations).map(([assetName, percentage]) => ({
      assetName,
      amount: (amount * percentage) / 100,
      percentage
    }));
  };

  const handleCalculate = () => {
    const amount = parseFloat(investmentAmount);
    if (!isNaN(amount) && amount > 0) {
      setRecommendations(calculateRecommendations(amount));
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-50 to-gray-100">
      <div className="max-w-7xl mx-auto px-4 py-8">
        <header className="mb-12">
          <div className="flex items-center gap-3 mb-2">
            <Briefcase className="w-8 h-8 text-indigo-600" />
            <h1 className="text-3xl font-bold text-gray-900">Investment Portfolio Advisor</h1>
          </div>
          <p className="text-gray-600">Track, analyze, and optimize your investments</p>
        </header>

        {/* Investment Calculator */}
        <div className="mb-8 bg-white rounded-2xl shadow-sm p-6">
          <div className="flex items-center gap-2 mb-6">
            <Calculator className="w-5 h-5 text-indigo-600" />
            <h2 className="text-xl font-semibold text-gray-900">Investment Calculator</h2>
          </div>

          <div className="flex flex-col md:flex-row gap-4 items-end mb-6">
            <div className="flex-1">
              <label htmlFor="amount" className="block text-sm font-medium text-gray-700 mb-2">
                How much would you like to invest?
              </label>
              <div className="relative">
                <span className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-500">$</span>
                <input
                  type="number"
                  id="amount"
                  value={investmentAmount}
                  onChange={(e) => setInvestmentAmount(e.target.value)}
                  className="block w-full pl-8 pr-4 py-2 rounded-lg border border-gray-300 focus:ring-2 focus:ring-indigo-200 focus:border-indigo-400"
                  placeholder="Enter amount"
                  min="0"
                />
              </div>
            </div>
            <button
              onClick={handleCalculate}
              className="px-6 py-2 bg-indigo-600 text-white rounded-lg hover:bg-indigo-700 transition-colors"
            >
              Calculate
            </button>
          </div>

          {recommendations.length > 0 && (
            <div className="space-y-4">
              <h3 className="text-lg font-semibold text-gray-900">Recommended Allocation</h3>
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
                {recommendations.map((rec) => (
                  <div key={rec.assetName} className="bg-gray-50 rounded-xl p-4">
                    <h4 className="font-medium text-gray-700 mb-2">{rec.assetName}</h4>
                    <div className="flex justify-between items-center">
                      <span className="text-lg font-semibold text-gray-900">
                        ${rec.amount.toLocaleString(undefined, { maximumFractionDigits: 0 })}
                      </span>
                      <span className="text-sm text-gray-500">{rec.percentage}%</span>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Portfolio Overview */}
          <div className="lg:col-span-2 bg-white rounded-2xl shadow-sm p-6">
            <div className="flex items-center justify-between mb-6">
              <h2 className="text-xl font-semibold text-gray-900">Portfolio Overview</h2>
              <div className="flex items-center gap-2">
                <DollarSign className="w-5 h-5 text-green-600" />
                <span className="text-2xl font-bold text-gray-900">
                  ${totalValue.toLocaleString()}
                </span>
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              {assets.map((asset) => (
                <div
                  key={asset.name}
                  className="bg-gray-50 rounded-xl p-4 border border-gray-100 cursor-pointer hover:border-indigo-200 transition-colors"
                  onClick={() => setSelectedAsset(asset)}
                >
                  <div className="flex items-center justify-between mb-2">
                    <h3 className="font-medium text-gray-700">{asset.name}</h3>
                    <span className="text-sm text-gray-500">{asset.allocation}%</span>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-lg font-semibold">
                      ${asset.value.toLocaleString()}
                    </span>
                    <div className={`flex items-center gap-1 ${
                      asset.change >= 0 ? 'text-green-600' : 'text-red-600'
                    }`}>
                      {asset.change >= 0 ? (
                        <ArrowUpRight className="w-4 h-4" />
                      ) : (
                        <ArrowDownRight className="w-4 h-4" />
                      )}
                      <span className="font-medium">{Math.abs(asset.change)}%</span>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Recommendations */}
          <div className="bg-white rounded-2xl shadow-sm p-6">
            <div className="flex items-center gap-2 mb-6">
              <TrendingUp className="w-5 h-5 text-indigo-600" />
              <h2 className="text-xl font-semibold text-gray-900">Recommendations</h2>
            </div>

            <div className="space-y-4">
              <div className="p-4 bg-green-50 rounded-xl border border-green-100">
                <h3 className="font-medium text-green-800 mb-1">Diversification Opportunity</h3>
                <p className="text-sm text-green-600">
                  Consider increasing bond allocation to reduce portfolio volatility
                </p>
              </div>

              <div className="p-4 bg-blue-50 rounded-xl border border-blue-100">
                <h3 className="font-medium text-blue-800 mb-1">Rebalancing Needed</h3>
                <p className="text-sm text-blue-600">
                  Stock allocation is above target. Consider rebalancing
                </p>
              </div>

              <div className="p-4 bg-purple-50 rounded-xl border border-purple-100">
                <h3 className="font-medium text-purple-800 mb-1">Tax Optimization</h3>
                <p className="text-sm text-purple-600">
                  Review tax-loss harvesting opportunities in your stock portfolio
                </p>
              </div>
            </div>
          </div>

          {/* Asset Allocation */}
          <div className="lg:col-span-3 bg-white rounded-2xl shadow-sm p-6">
            <div className="flex items-center gap-2 mb-6">
              <PieChart className="w-5 h-5 text-indigo-600" />
              <h2 className="text-xl font-semibold text-gray-900">Asset Allocation</h2>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
              {assets.map((asset) => (
                <div key={asset.name} className="flex flex-col items-center">
                  <div className="w-full bg-gray-200 rounded-full h-2 mb-2">
                    <div
                      className="bg-indigo-600 h-2 rounded-full"
                      style={{ width: `${asset.allocation}%` }}
                    />
                  </div>
                  <span className="text-sm font-medium text-gray-700">{asset.name}</span>
                  <span className="text-sm text-gray-500">{asset.allocation}%</span>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>

      {selectedAsset && (
        <AssetDetailsModal
          asset={selectedAsset}
          onClose={() => setSelectedAsset(null)}
        />
      )}
    </div>
  );
}

export default App;